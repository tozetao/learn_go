package ginx

type Result struct {
	Code int
	Msg  string
	Data interface{}
}
