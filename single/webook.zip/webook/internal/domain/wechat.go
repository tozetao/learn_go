package domain

type WechatInfo struct {
	UnionId string
	OpenId  string
}
