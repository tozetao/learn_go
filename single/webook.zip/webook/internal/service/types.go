package service

import "learn_go/webook/internal/repository"

var (
	ErrNotFound = repository.ErrNotFound
)
