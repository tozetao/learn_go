package repository

import "learn_go/webook/internal/repository/dao"

var (
	ErrNotFound = dao.ErrNotFound
)
