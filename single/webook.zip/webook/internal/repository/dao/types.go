package dao

import "gorm.io/gorm"

var (
	ErrNotFound = gorm.ErrRecordNotFound
)
